# LAN Bounty Mobile

Mobile-first LAN multiplayer browser game with a Colt-inspired six-shot brawler.

## Host setup
Requires Node.js 18+ on a computer.
1. Extract this folder.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. On the host computer visit `http://localhost:3000`.

## Play on Android / Galaxy Tab
Connect the tablet and host computer to the same Wi-Fi. Find the host computer's local IPv4 address (Windows: run `ipconfig`, find IPv4 Address). In Chrome on the tablet, open `http://HOST-LAN-IP:3000`. The host firewall must allow incoming connections on port 3000. Guest Wi-Fi or client isolation can block LAN play.

## Controls
- Hold and drag the left joystick to move.
- Touch/drag the right control area to aim.
- Hold FIRE to shoot.

## Game rules
- 6200 maximum health.
- Each shot fires 6 bullets; each bullet deals 720 damage.
- 3 ammo charges maximum; one charge reloads every 0.7 seconds.
- Health regenerates at 1200 per second after 3 seconds without attacking or taking damage.
- Each kill awards 2 base points plus the defeated player's bounty; your bounty rises by 1 per kill, capped at 7.
- First player to 20 points wins. If the 3-minute timer expires, the highest score wins.
- The bars below the arena show your health and three ammo charges. Score and bounty are also shown above each brawler.

This is an original prototype with placeholder graphics, not official Brawl Stars content. Arena blocks are decorative and do not stop bullets or players.
